<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Management System</title>
  </head>


<body>
    <h3 style="text-align:right; text-decoration:none;"><a href="login.php">Admin Login</a></h3>
    <h1 style="text-align:center">Welcome to Student Information System</h1>
    <form float=" !important" style=" margin:auto;border: 2px solid; width:50vw" action="index.php" method="post">
        <table style="width:100%;height:20vh">
            <tr>
                <th colspan=2 style="border:1px solid;">Student Information</th>
            </tr>
            <tr>
                <td style="border:1px solid;">Standard</td>
                <td style="border:1px solid;">
                    <select name="std">
                        <option value="1">1st</option>
                        <option value="2">2nd</option>
                        <option value="3">3rd</option>
                        <option value="4">4th</option>
                        <option value="5">5th</option>
                        <option value="6">6th</option>
                        <option value="7">7th</option>
                        <option value="8">8th</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td style="border:1px solid;">Enter Roll No.</td=>
              <td style="border:1px solid;"><input type="text" name="rollno" placeholder="Enter Roll No." required /> </td>
            </tr>
            <tr>
                <td colspan=2 style="border:1px solid;padding:auto">
                    <div style="margin:auto; width: 85px">
                    <button type="submit" style="width:100%" name="submit" value="Show Info">Show Info</button>

                    </div>
                </td>
            </tr>
        </table>
    </form>
</body>
</html>

<?php 
  if(isset($_POST['submit']))
  {
    $standard = $_POST['std'];
    $rollno = $_POST['rollno'];

    include('dbcon.php');

    include('function.php');
    showdetails($standard, $rollno);
  }
?>