<?php
session_start();

   if($_SESSION ['uid'] )  
    {
        echo "";
    }
    else
    {
        header('location: ../login.php');
    }
?>


<?php 
    include('header.php');
    include('titleheader.php');
    include('../dbcon.php');

    $sid= $_GET['sid'];
    // $sql = "SELECT * FROM `student` WHERE `id`='$sid'";

    $query = "SELECT * FROM  student WHERE id = '$sid'";
    $run = mysqli_query($con,$query);

    $data= mysqli_fetch_assoc($run);
?>

<form  method="post" action="updatedata.php" enctype="multipart/form-data">
    <table  align="center"; border="2px solid black"  width="70%" margin-top="40px">
        <tr>
            <th>Roll No. </th>
            <td><input type="text" name="rollno" value=<?php echo $data['rollno'];?> required></td>
        </tr>
        <tr>
            <th>Name </th>
            <td><input type="text" name="name" value=<?php echo $data['name'];?> required></td>
        </tr>
        <tr>
            <th> City</th>
            <td><input type="text" name="city" value=<?php echo $data['city'];?> required></td>
        </tr>
        <tr>
            <th>Standard </th>
            <td><input type="text" name="std" value=<?php echo $data['standard'];?> required></td>
        </tr>
        <tr>
            <th>Parent Contact </th>
            <td><input type="text" name="pcont" value=<?php echo $data['pcontact'];?> required></td>
        </tr>
        <tr>
            <th>Image </th>
            <td><input type="file" name="simg" placeholder="Enter Student Image" required></td>
        </tr>
        <tr>
            <td colspan='2' align="center" margin="left">
            <input type="hidden" name="sid" value="<?php echo $data['id']; ?>" /> 
            <input type="submit" name="submit" value="Submit"> 
</td>
        </tr>
    </table>
   </form>


   