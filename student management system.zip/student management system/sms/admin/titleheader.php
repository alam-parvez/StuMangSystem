<div class="admintitle" style="text-align:center">
<h4><a href="admindash.php" style="float:left; margin-left:30px; color:#fff; font-size:25px; text-decoration:none;">Back to Dashboard</a></h4>
       <h4><a href="logout.php" style="float:right; margin-right:30px; color:#fff; font-size:25px; text-decoration:none;">Logout</a></h4>
        <h1>Welcome to Admin Dashboard</h1>
   </div>
