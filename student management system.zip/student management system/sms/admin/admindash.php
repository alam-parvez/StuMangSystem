<?php
session_start();

   if($_SESSION ['uid'] )  
    {
        echo "";
    }
    else
    {
        header('location: ../login.php');
    }
 ?>

<?php
include('header.php');
?>

   <div class="admintitle" style="text-align:center">
       <h4><a href="logout.php" style="float:right; margin-right:30px; color:#fff; font-size:25px; text-decoration:none;">Logout</a></h4>
        <h1>Welcome to Admin Dashboard</h1>
   </div>

   <div class="dashboard">
   <table  style="align:center; color:#fff; border:2px solid black;margin:auto; width:70%; font-size:30px;" height="140px" >
      
        <tr>
            <th colspan='2'>
                <td>1.</td><td><a href="addstudent.php">Insert Student Details</a></td>
            </th>
      
            <th colspan='2'>
                <td>2.</td><td><a href="updatestudent.php">Update Student Details</a></td>
            </th>
      
            <th colspan='2'>
                <td>3.</td><td><a href="deletestudent.php">Delete Student Details</a></td>
            </th>
        </tr>
       </table>
   </div>
</body>
</html>