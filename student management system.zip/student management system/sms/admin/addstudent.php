<?php
session_start();

   if($_SESSION ['uid'] )  
    {
        echo "";
    }
    else
    {
        header('location: ../login.php');
    }
 ?>

<?php
include('header.php');
include('titleheader.php');
?>

<form action="addstudent.php" method="post" enctype="multipart/form-data">
   
    <table  align="center"; border="2px solid black"  width="70%" margin-top="40px">
    <!-- <table  style="align:center; border:2px solid black; width:70% margin-top:40px" > -->
        <tr>
            <th>Roll No. </th>
            <td><input type="text" name="rollno" placeholder="Enter Roll No." required></td>
        </tr>

        <tr>
            <th>Name </th>
            <td><input type="text" name="name" placeholder="Enter Student Name" required></td>
        </tr>

        <tr>
            <th> City</th>
            <td><input type="text" name="city" placeholder="Enter City" required></td>
        </tr>

        <tr>
            <th>Standard </th>
            <td><input type="text" name="std" placeholder="Enter Standard" required></td>
        </tr>

        <tr>
            <th>Parent Contact </th>
            <td><input type="text" name="pcont" placeholder="Enter Parents Contact No." required></td>
        </tr>

        <tr>
            <th>Image </th>
            <td><input type="file" name="simg" placeholder="Enter Student Image" required></td>
        </tr>

        <tr>
            <th colspan='2' style="align:center;"><input type="submit" name="submit" value="Submit" ></th>
        </tr>
    </table>
   </form>
  </body>
</html>

<?php
  if(isset($_POST['submit']))
{
    include('../dbcon.php');
        
        $rollno = $_POST['rollno'];
        $name= $_POST['name'];
        $city= $_POST['city'];
        $std= $_POST['std'];
        $pcont= $_POST['pcont'];
        $imagename= $_FILES['simg']['name'];

        $tp_img = $_FILES['simg']['tmp_name'];   //important

        move_uploaded_file($tp_img,"../dataimg/$imagename");


    $qry="INSERT INTO `student`(`rollno`, `name`, `city`, `standard`, `pcontact`,`image`) VALUES ('$rollno','$name','$city','$std','$pcont','$imagename')";
        // echo "$qry";
    $run = mysqli_query($con, $qry);

        if($run == true)
        {
            ?>
            <script>
                alert(`Data Inserted Successfully`);
            </script>
            <?php
        }
 }
?>