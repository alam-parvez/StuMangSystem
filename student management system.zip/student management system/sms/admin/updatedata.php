<?php


include('../dbcon.php');


    $rollno = $_POST['rollno'];
    $name= $_POST['name'];
    $city= $_POST['city'];
    $standard= $_POST['std'];
    $id= $_POST['sid']; 
    $pcont= $_POST['pcont'];
    $imagename= $_FILES['simg']['name'];
    $tp_img = $_FILES['simg']['tmp_name'];   //important

    move_uploaded_file($tp_img,"../dataimg/$imagename");

    $qry ="UPDATE `student` SET `rollno` = '$rollno', `name` = '$name', `city` = '$city', `standard` = '$standard', `pcontact` = '$pcont' WHERE `id` = $id;";

    $run = mysqli_query($con,$qry);

        if($run == true)
        {
            ?>
            <script>
                alert(`Data Updated Successfully`);
                window.open('updateform.php?sid=<?php echo $id;?>','_self');
            </script>
            <?php
        }
    ?>