<?php
session_start();

   if($_SESSION ['uid'] )  
    {
        echo "";
    }
    else
    {
        header('location: ../login.php');
    }
?>


<?php
include("header.php");
include("titleheader.php");
?>


<table style="text-align:center; margin:auto;"  width="50%" margin-top="40px">
    <form action="updatestudent.php" method="post">
        <tr>
            <th>Enter Standard</th>
            <td><input type="number" name="standard" placeholder="Enter Standard" required/></td>
            <th>Enter Student Name</th>
            <td><input type="text" name="stuname" placeholder="Enter Student Name" required/></td>

            <td colspan="2"><input type="submit" name="submit" value="Search"></td>
        </tr>
    </form>

    
</table>


<table border = "2px solid" style=" solid;text-align:center;  margin:auto; width:80%;">
<tr style="background-color:#000; color:#ffffff;margin:auto;">
        <td>No</td>
        <td>Image</td>
        <td>Name</td>
        <td>Rollno</td>
        <td>Edit</td>
    </tr>



<?php

if(isset($_POST['submit']))
{

     include('../dbcon.php');

     $standard = $_POST['standard'];
     $name = $_POST['stuname'];

    $sql = "SELECT * FROM `student` WHERE `standard`='$standard' AND `name` LIKE '%$name%'";
    $run = mysqli_query($con,$sql);

    if(mysqli_num_rows($run)<1)
    {
        echo "<tr><td colspan='5'>No Records Found</td></tr>";
    }

    else{

        $count=0;
        while($data = mysqli_fetch_assoc($run))
        {
           $count++;
        ?>
       
        <tr>
            <td><?php echo $count; ?></td>
            <td style="height:200px; width:140px;"><img src="../dataimg/<?php echo $data['image'];?>"  style="height:100%; width:100%" alt=""></td>
            <td><?php echo $data['name']; ?></td>
            <td><?php echo $data['rollno']; ?></td>
            <td><a href="updateform.php?sid=<?php echo $data['id'];?>">Edit</a></td>
        </tr>
    <?php
       }
    }
}
    ?>
    </table>
<?php
?>