<?php
function showdetails($standard,$rollno)
{
    include('dbcon.php');

    $qry = "SELECT * FROM `student` WHERE  `standard`='$standard' AND `rollno`='$rollno'";
   

    $run = mysqli_query($con,$qry);

    if(mysqli_num_rows($run)>0)
       {
            $data = mysqli_fetch_assoc($run);
            ?>
             <table  align="center"; border="2px solid black"  width="50%" margin-top="40px">
            
                    <tr>
                        <td colspan="3" margin="left">Student Details</td>
                    </tr>
                    <tr>
                        <td rowspan="5"><img src="dataimg/<?php echo $data['image']; ?> " alt="" style="max-height:150px; max-width:200px;"></td>
                        <th>rollno</th>
                        <td><?php echo $data['rollno']; ?></td>
                    </tr>
                    <tr>
                        <th>Name</th>
                        <td><?php echo $data['name']; ?></td>
                    </tr>
                    <tr>
                        <th>Standard</th>
                        <td><?php echo $data['standard']; ?></td>
                    </tr>
                    <tr>
                        <th>Parent Contact No</th>
                        <td><?php echo $data['pcontact']; ?></td>
                    </tr>
                    <tr>
                        <th>City</th>
                        <td><?php echo $data['city']; ?></td>
                    </tr>
            </table>
            <?php
    }
    else{
            echo "<script>alert('No Student Found.');</script>";
    }
}
?>