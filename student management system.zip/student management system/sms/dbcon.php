<?php 

$con =  mysqli_connect('localhost','root','','sms');

if($con == false)
{
     echo "connection is not established";
}
// else{
//   echo "connection is ok";
// }



?>