<?php
   session_start();
  if(isset($_SESSION['uid']))
  {
    header('location:admin/admindash.php');
  }


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Admin</title>
</head>
<body>
    <h1 style="text-align:center">Admin Login</h1>
    <form style="text-align:center" action="login.php" method="post">
        <label for="username">Enter username</label>
        <input type="text" name="uname"  placeholder="Enter Username" required/>
        <br><br>
        <label for="password">Enter Password</label>
        <input type="password" name="pass"  placeholder="Enter Password" required/>
        <br><br>
        <button type="submit" name="login" value="login">Admin Login</button>
    </form>
</body>
</html>

<?php

include('dbcon.php');

if(isset($_POST['login']))
{
    $username = $_POST['uname'];
    $password = $_POST['pass'];

    $qry ="SELECT * FROM `admin` WHERE `username`='$username' AND `password`='$password'";
    $run = mysqli_query($con,$qry);
    $row = mysqli_num_rows($run);
    if($row<1)
          
    {
        ?>    
            <script>
                alert('Username or Password does not match !!');
                window.open('login.php','_self');
            </script>
       <?php
    }
    else{
        $data = mysqli_fetch_assoc($run);
        $id = $data['id'];

        // echo "id = ".$id;
          
        $_SESSION['uid'] = $id;
        header('location:admin/admindash.php');
    }
   

}
?>